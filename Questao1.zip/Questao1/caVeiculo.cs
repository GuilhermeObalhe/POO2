﻿public abstract class caVeiculo
{
    // Atributos
    protected string placaVeiculo;
    protected int anoVeiculo;

    // Construtor
    public caVeiculo(string placa, int ano)
    {
        this.placaVeiculo = placa;
        this.anoVeiculo = ano;
    }

    // Getters e Setters
    public string PlacaVeiculo { get => placaVeiculo; }
    public int AnoVeiculo { get => anoVeiculo; }
    public abstract double Alugar();
}
