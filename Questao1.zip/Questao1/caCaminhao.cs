﻿internal class caCaminhao : caVeiculo
{
    // Atributos
    private int eixosVeiculo;
    private double diariaVeiculo;

    // Construtor
    public caCaminhao(string placa, int ano, int eixos) : base(placa, ano)
    {
        this.eixosVeiculo = eixos;
        this.diariaVeiculo = Alugar();
    }

    // Getters e Setters
    public int EixosVeiculo { get => eixosVeiculo; }
    public double DiariaVeiculo { get => diariaVeiculo; }

    public override double Alugar()
    {
        int anoAtual = 2024;
        return (300 * eixosVeiculo) - (anoAtual - anoVeiculo) * 50;
    }
}
