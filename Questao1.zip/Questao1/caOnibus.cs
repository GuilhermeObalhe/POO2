﻿internal class caOnibus : caVeiculo
{
    // Atributos
    private int assentosVeiculo;
    private double diariaVeiculo;

    // Construtor
    public caOnibus(string placa, int ano, int assentos) : base(placa, ano)
    {
        this.assentosVeiculo = assentos;
        this.diariaVeiculo = Alugar();
    }

    // Getters e Setters
    public int AssentosVeiculo { get => assentosVeiculo; }
    public double DiariaVeiculo { get => diariaVeiculo; }

    public override double Alugar()
    {
        int anoAtual = 2024;
        return (30 * assentosVeiculo) - (anoAtual - anoVeiculo) * 70;
    }
}
