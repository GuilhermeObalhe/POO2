﻿namespace Questao1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbOnibus = new System.Windows.Forms.RadioButton();
            this.rbCaminhao = new System.Windows.Forms.RadioButton();
            this.pnOnibus = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLimparOnibus = new System.Windows.Forms.Button();
            this.btnCadastrarOnibus = new System.Windows.Forms.Button();
            this.tbAssentos = new System.Windows.Forms.TextBox();
            this.tbAnoOnibus = new System.Windows.Forms.TextBox();
            this.mtbPlacaOnibus = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dGVVeiculos = new System.Windows.Forms.DataGridView();
            this.PlacaVeiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AnoVeiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssentosVeiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EixosVeiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiariaVeiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnCaminhao = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnLimparCaminhao = new System.Windows.Forms.Button();
            this.btnCadastrarCaminhao = new System.Windows.Forms.Button();
            this.tbEixos = new System.Windows.Forms.TextBox();
            this.tbAnoCaminhao = new System.Windows.Forms.TextBox();
            this.mtbPlacaCaminhao = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pnOnibus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGVVeiculos)).BeginInit();
            this.pnCaminhao.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // rbOnibus
            // 
            this.rbOnibus.AutoSize = true;
            this.rbOnibus.Location = new System.Drawing.Point(85, 41);
            this.rbOnibus.Name = "rbOnibus";
            this.rbOnibus.Size = new System.Drawing.Size(58, 17);
            this.rbOnibus.TabIndex = 0;
            this.rbOnibus.TabStop = true;
            this.rbOnibus.Text = "Ônibus";
            this.rbOnibus.UseVisualStyleBackColor = true;
            this.rbOnibus.CheckedChanged += new System.EventHandler(this.rbOnibus_CheckedChanged);
            // 
            // rbCaminhao
            // 
            this.rbCaminhao.AutoSize = true;
            this.rbCaminhao.Location = new System.Drawing.Point(198, 41);
            this.rbCaminhao.Name = "rbCaminhao";
            this.rbCaminhao.Size = new System.Drawing.Size(72, 17);
            this.rbCaminhao.TabIndex = 1;
            this.rbCaminhao.TabStop = true;
            this.rbCaminhao.Text = "Caminhão";
            this.rbCaminhao.UseVisualStyleBackColor = true;
            this.rbCaminhao.CheckedChanged += new System.EventHandler(this.rbCaminhao_CheckedChanged);
            // 
            // pnOnibus
            // 
            this.pnOnibus.BackColor = System.Drawing.SystemColors.Control;
            this.pnOnibus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnOnibus.Controls.Add(this.pictureBox1);
            this.pnOnibus.Controls.Add(this.btnLimparOnibus);
            this.pnOnibus.Controls.Add(this.btnCadastrarOnibus);
            this.pnOnibus.Controls.Add(this.tbAssentos);
            this.pnOnibus.Controls.Add(this.tbAnoOnibus);
            this.pnOnibus.Controls.Add(this.mtbPlacaOnibus);
            this.pnOnibus.Controls.Add(this.label3);
            this.pnOnibus.Controls.Add(this.label2);
            this.pnOnibus.Controls.Add(this.label1);
            this.pnOnibus.Location = new System.Drawing.Point(85, 78);
            this.pnOnibus.Name = "pnOnibus";
            this.pnOnibus.Size = new System.Drawing.Size(564, 229);
            this.pnOnibus.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Questao1.Properties.Resources.Onibus;
            this.pictureBox1.Location = new System.Drawing.Point(337, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(216, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // btnLimparOnibus
            // 
            this.btnLimparOnibus.Location = new System.Drawing.Point(262, 158);
            this.btnLimparOnibus.Name = "btnLimparOnibus";
            this.btnLimparOnibus.Size = new System.Drawing.Size(111, 31);
            this.btnLimparOnibus.TabIndex = 8;
            this.btnLimparOnibus.Text = "Limpar";
            this.btnLimparOnibus.UseVisualStyleBackColor = true;
            // 
            // btnCadastrarOnibus
            // 
            this.btnCadastrarOnibus.Location = new System.Drawing.Point(73, 158);
            this.btnCadastrarOnibus.Name = "btnCadastrarOnibus";
            this.btnCadastrarOnibus.Size = new System.Drawing.Size(111, 31);
            this.btnCadastrarOnibus.TabIndex = 7;
            this.btnCadastrarOnibus.Text = "Cadastrar";
            this.btnCadastrarOnibus.UseVisualStyleBackColor = true;
            this.btnCadastrarOnibus.Click += new System.EventHandler(this.btnCadastrarOnibus_Click);
            // 
            // tbAssentos
            // 
            this.tbAssentos.Location = new System.Drawing.Point(126, 113);
            this.tbAssentos.Name = "tbAssentos";
            this.tbAssentos.Size = new System.Drawing.Size(100, 20);
            this.tbAssentos.TabIndex = 5;
            // 
            // tbAnoOnibus
            // 
            this.tbAnoOnibus.Location = new System.Drawing.Point(126, 81);
            this.tbAnoOnibus.Name = "tbAnoOnibus";
            this.tbAnoOnibus.Size = new System.Drawing.Size(100, 20);
            this.tbAnoOnibus.TabIndex = 4;
            // 
            // mtbPlacaOnibus
            // 
            this.mtbPlacaOnibus.Location = new System.Drawing.Point(126, 43);
            this.mtbPlacaOnibus.Name = "mtbPlacaOnibus";
            this.mtbPlacaOnibus.Size = new System.Drawing.Size(68, 20);
            this.mtbPlacaOnibus.TabIndex = 3;
            this.mtbPlacaOnibus.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Qtd Assentos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ano";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Placa";
            // 
            // dGVVeiculos
            // 
            this.dGVVeiculos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dGVVeiculos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVVeiculos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PlacaVeiculo,
            this.AnoVeiculo,
            this.AssentosVeiculo,
            this.EixosVeiculo,
            this.DiariaVeiculo});
            this.dGVVeiculos.Location = new System.Drawing.Point(85, 316);
            this.dGVVeiculos.Name = "dGVVeiculos";
            this.dGVVeiculos.Size = new System.Drawing.Size(539, 122);
            this.dGVVeiculos.TabIndex = 6;
            // 
            // PlacaVeiculo
            // 
            this.PlacaVeiculo.HeaderText = "Placa";
            this.PlacaVeiculo.Name = "PlacaVeiculo";
            // 
            // AnoVeiculo
            // 
            this.AnoVeiculo.HeaderText = "Ano";
            this.AnoVeiculo.Name = "AnoVeiculo";
            // 
            // AssentosVeiculo
            // 
            this.AssentosVeiculo.HeaderText = "Assentos";
            this.AssentosVeiculo.Name = "AssentosVeiculo";
            // 
            // EixosVeiculo
            // 
            this.EixosVeiculo.HeaderText = "Eixos";
            this.EixosVeiculo.Name = "EixosVeiculo";
            // 
            // DiariaVeiculo
            // 
            this.DiariaVeiculo.HeaderText = "Diaria";
            this.DiariaVeiculo.Name = "DiariaVeiculo";
            // 
            // pnCaminhao
            // 
            this.pnCaminhao.Controls.Add(this.pictureBox2);
            this.pnCaminhao.Controls.Add(this.btnLimparCaminhao);
            this.pnCaminhao.Controls.Add(this.btnCadastrarCaminhao);
            this.pnCaminhao.Controls.Add(this.tbEixos);
            this.pnCaminhao.Controls.Add(this.tbAnoCaminhao);
            this.pnCaminhao.Controls.Add(this.mtbPlacaCaminhao);
            this.pnCaminhao.Controls.Add(this.label4);
            this.pnCaminhao.Controls.Add(this.label5);
            this.pnCaminhao.Controls.Add(this.label6);
            this.pnCaminhao.Location = new System.Drawing.Point(85, 81);
            this.pnCaminhao.Name = "pnCaminhao";
            this.pnCaminhao.Size = new System.Drawing.Size(645, 229);
            this.pnCaminhao.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Questao1.Properties.Resources.Caminhao;
            this.pictureBox2.Location = new System.Drawing.Point(336, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(216, 129);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            // 
            // btnLimparCaminhao
            // 
            this.btnLimparCaminhao.Location = new System.Drawing.Point(261, 153);
            this.btnLimparCaminhao.Name = "btnLimparCaminhao";
            this.btnLimparCaminhao.Size = new System.Drawing.Size(111, 31);
            this.btnLimparCaminhao.TabIndex = 18;
            this.btnLimparCaminhao.Text = "Limpar";
            this.btnLimparCaminhao.UseVisualStyleBackColor = true;
            // 
            // btnCadastrarCaminhao
            // 
            this.btnCadastrarCaminhao.Location = new System.Drawing.Point(72, 153);
            this.btnCadastrarCaminhao.Name = "btnCadastrarCaminhao";
            this.btnCadastrarCaminhao.Size = new System.Drawing.Size(111, 31);
            this.btnCadastrarCaminhao.TabIndex = 17;
            this.btnCadastrarCaminhao.Text = "Cadastrar";
            this.btnCadastrarCaminhao.UseVisualStyleBackColor = true;
            this.btnCadastrarCaminhao.Click += new System.EventHandler(this.btnCadastrarCaminhao_Click);
            // 
            // tbEixos
            // 
            this.tbEixos.Location = new System.Drawing.Point(125, 104);
            this.tbEixos.Name = "tbEixos";
            this.tbEixos.Size = new System.Drawing.Size(100, 20);
            this.tbEixos.TabIndex = 15;
            // 
            // tbAnoCaminhao
            // 
            this.tbAnoCaminhao.Location = new System.Drawing.Point(125, 72);
            this.tbAnoCaminhao.Name = "tbAnoCaminhao";
            this.tbAnoCaminhao.Size = new System.Drawing.Size(100, 20);
            this.tbAnoCaminhao.TabIndex = 14;
            // 
            // mtbPlacaCaminhao
            // 
            this.mtbPlacaCaminhao.Location = new System.Drawing.Point(125, 38);
            this.mtbPlacaCaminhao.Name = "mtbPlacaCaminhao";
            this.mtbPlacaCaminhao.Size = new System.Drawing.Size(68, 20);
            this.mtbPlacaCaminhao.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Qtd Eixos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Ano";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Placa";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rbCaminhao);
            this.Controls.Add(this.rbOnibus);
            this.Controls.Add(this.dGVVeiculos);
            this.Controls.Add(this.pnOnibus);
            this.Controls.Add(this.pnCaminhao);
            this.Name = "Form1";
            this.Text = "Cadastro de Veículos";
            this.pnOnibus.ResumeLayout(false);
            this.pnOnibus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGVVeiculos)).EndInit();
            this.pnCaminhao.ResumeLayout(false);
            this.pnCaminhao.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbOnibus;
        private System.Windows.Forms.RadioButton rbCaminhao;
        private System.Windows.Forms.Panel pnOnibus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dGVVeiculos;
        private System.Windows.Forms.TextBox tbAssentos;
        private System.Windows.Forms.TextBox tbAnoOnibus;
        private System.Windows.Forms.MaskedTextBox mtbPlacaOnibus;
        private System.Windows.Forms.Button btnLimparOnibus;
        private System.Windows.Forms.Button btnCadastrarOnibus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnCaminhao;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnLimparCaminhao;
        private System.Windows.Forms.Button btnCadastrarCaminhao;
        private System.Windows.Forms.TextBox tbEixos;
        private System.Windows.Forms.TextBox tbAnoCaminhao;
        private System.Windows.Forms.MaskedTextBox mtbPlacaCaminhao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn PlacaVeiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn AnoVeiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssentosVeiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EixosVeiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiariaVeiculo;
    }
}

