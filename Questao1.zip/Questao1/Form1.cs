﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questao1
{
    public partial class Form1 : Form
    {
        // Criando a lista de veículos
        List<caVeiculo> veiculos = new List<caVeiculo>();

        public Form1()
        {
            InitializeComponent();
            dGVVeiculos.DataSource = veiculos;
        }

        private void rbOnibus_CheckedChanged(object sender, EventArgs e)
        {
            pnOnibus.Visible = true;
            pnCaminhao.Visible = false;
        }

        private void rbCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            pnOnibus.Visible = false;
            pnCaminhao.Visible = true;
        }

        private void btnCadastrarOnibus_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(mtbPlacaOnibus.Text) ||
                string.IsNullOrWhiteSpace(tbAnoOnibus.Text) ||
                string.IsNullOrWhiteSpace(tbAssentos.Text))
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
                return;
            }

            caOnibus novoOnibus = new caOnibus(
                mtbPlacaOnibus.Text,
                Convert.ToInt32(tbAnoOnibus.Text),
                Convert.ToInt32(tbAssentos.Text)
            );

            veiculos.Add(novoOnibus);

            // Atualiza o DataGridView
            dGVVeiculos.DataSource = null; // Limpa a fonte atual
            dGVVeiculos.DataSource = veiculos; // Define a nova fonte
        }

        private void btnCadastrarCaminhao_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(mtbPlacaCaminhao.Text) ||
                string.IsNullOrWhiteSpace(tbAnoCaminhao.Text) ||
                string.IsNullOrWhiteSpace(tbEixos.Text))
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
                return; // Não continue se algum campo estiver vazio
            }

            caCaminhao novoCaminhao = new caCaminhao(
                mtbPlacaCaminhao.Text,
                Convert.ToInt32(tbAnoCaminhao.Text),
                Convert.ToInt32(tbEixos.Text)
            );

            veiculos.Add(novoCaminhao);

            // Atualiza o DataGridView
            dGVVeiculos.DataSource = null; // Limpa a fonte atual
            dGVVeiculos.DataSource = veiculos; // Define a nova fonte
        }
    }
}
