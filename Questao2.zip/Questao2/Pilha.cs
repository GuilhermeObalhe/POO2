﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao2
{
    internal class Pilha
    {
        // Atributos
        private NoPilha Topo;

        // Construtor
        public Pilha()
        {
            this.Topo = null;
        }

        // Métodos
        public bool EstaVazia()
        {
            return Topo == null;
        }

        // Adicionar elemento à pilha
        public void push(string peca)
        {
            NoPilha novoNo = new NoPilha(peca);
            if (EstaVazia())
            {
                Topo = novoNo;
            }
            else
            {
                novoNo.Proximo = Topo;
                Topo = novoNo;
            }
        }

        // Remover elemento da pilha
        public string pop()
        {
            if (EstaVazia())
            {
                Console.WriteLine("A pilha está vazia!");
                return null;
            }
            string peca = Topo.Peca;
            Topo = Topo.Proximo;
            return peca;
        }

        // Método para imprimir
        public void Imprime()
        {
            if (EstaVazia())
            {
                Console.WriteLine("A pilha está vazia!");
            }
            else
            {
                NoPilha temp = Topo;
                while (temp != null)
                {
                    Console.WriteLine(temp.Peca);
                    temp = temp.Proximo;
                }
            }
        }

        public void TrocarPeca(string pecaAntiga, string pecaNova)
        {
            if (EstaVazia())
            {
                Console.WriteLine("A pilha está vazia!");
                return;
            }

            Pilha pilhaTemporaria = new Pilha();
            bool pecaEncontrada = false;

            // Remove peças até encontrar a peça antiga
            while (!EstaVazia())
            {
                string pecaAtual = pop();
                if (pecaAtual == pecaAntiga)
                {
                    pecaEncontrada = true;
                    pilhaTemporaria.push(pecaNova);
                    break;
                }
                // Armazena as peças removidas na pilha temporária
                pilhaTemporaria.push(pecaAtual);
            }

            // Se a peça antiga foi encontrada, reinserimos as peças removidas
            if (pecaEncontrada)
            {
                while (!pilhaTemporaria.EstaVazia())
                {
                    push(pilhaTemporaria.pop());
                }
            }
            else
            {
                Console.WriteLine($"Peça {pecaAntiga} não encontrada.");
                // Reinsere todas as peças que foram removidas
                while (!pilhaTemporaria.EstaVazia())
                {
                    push(pilhaTemporaria.pop());
                }
            }
        }

        // Getter e Setter
        private NoPilha Topo1 { get => Topo; set => Topo = value; }
    }
}
