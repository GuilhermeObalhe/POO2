﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pilha pilha = new Pilha();

            // Adiciona peças à pilha
            pilha.push("Cúpula de Vidro");
            pilha.push("Lâmpada");
            pilha.push("Hélice");

            // Exibe as peças antes da troca
            Console.WriteLine("Antes da troca:");
            pilha.Imprime();

            // Troca uma peça
            Console.WriteLine("Digite a peca a ser trocada: ");
            string peca = Console.ReadLine();

            Console.WriteLine("Digite a peca nova: ");
            string pecaNova = Console.ReadLine();
            pilha.TrocarPeca(peca, pecaNova); // Troca peca por pecaNova

            // Exibe as peças após a troca
            Console.WriteLine("\nApós a troca:");
            pilha.Imprime();
            Console.ReadLine();
        }
    }
}
