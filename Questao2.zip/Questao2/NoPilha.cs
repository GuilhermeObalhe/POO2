﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao2
{
    internal class NoPilha
    {
        // Atributos
        private string peca;
        private NoPilha proximo;

        // Construtor
        public NoPilha(string peca)
        {
            this.peca = peca;
            this.proximo = null;
        }

        // Getters e Setters
        public string Peca { get => peca; set => peca = value; }
        internal NoPilha Proximo { get => proximo; set => proximo = value; }
    }
}
